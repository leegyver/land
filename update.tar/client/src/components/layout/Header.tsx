import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Building, LogIn, LogOut, User, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Header = () => {
  const [location, setLocation] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { name: "홈", path: "/" },
    { name: "모든매물보기", path: "/properties" },
    { name: "강화도뉴스", path: "/news" },
    { name: "부동산소개", path: "/about" },
    { name: "유튜브", path: "/youtube" },
    { name: "오늘의 운세", path: "/saju" },
    { name: "커뮤니티", path: "/community" },
    { name: "문의하기", path: "/contact" },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white/95 backdrop-blur-sm shadow-sm sticky top-0 w-full z-50 border-b border-slate-200">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center">
            <Building className="text-blue-600 text-3xl mr-2" />
            <span className="text-lg md:text-2xl font-bold text-slate-900">강화도부동산-이가이버</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={`font-medium hover:text-primary transition-colors ${location === item.path ? "text-primary" : "text-neutral-800"
                  }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Auth Buttons (Desktop) */}
          <div className="hidden md:flex items-center space-x-2">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <User size={18} />
                    <span className="font-medium">
                      {user.username}
                      {/* @ts-ignore */}
                      {user.provider && (
                        <span className="ml-1 text-xs text-slate-400">
                          {/* @ts-ignore */}
                          ({user.provider === 'naver' ? '네이버' : user.provider === 'kakao' ? '카카오' : user.provider})
                        </span>
                      )}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>내 계정</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => setLocation("/profile")} className="flex items-center w-full cursor-pointer">
                    <User className="mr-2 h-4 w-4" />
                    <span>내 프로필</span>
                  </DropdownMenuItem>
                  {user.role === "admin" && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setLocation("/admin")} className="flex items-center w-full cursor-pointer">
                        <Settings className="mr-2 h-4 w-4" />
                        <span>관리자 패널</span>
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>로그아웃</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="default" asChild>
                <Link href="/auth" className="flex items-center">
                  <LogIn className="mr-2 h-4 w-4" />
                  로그인
                </Link>
              </Button>
            )}
          </div>

          {/* Mobile Navigation */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="default" className="md:hidden px-3 py-2 text-sm font-bold bg-slate-900 hover:bg-slate-800 text-white shadow-md">
                모든메뉴보기
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col space-y-4 mt-8">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    href={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`text-lg font-medium hover:text-primary transition-colors ${location === item.path ? "text-primary" : "text-neutral-800"
                      }`}
                  >
                    {item.name}
                  </Link>
                ))}

                {/* Auth Items (Mobile) */}
                <div className="pt-4 border-t">
                  {user ? (
                    <>
                      <div className="flex items-center mb-4 text-primary font-medium">
                        <User size={18} className="mr-2" />
                        <span>
                          {user.username}
                          {/* @ts-ignore */}
                          {user.provider && (
                            <span className="ml-1 text-xs text-indigo-400">
                              {/* @ts-ignore */}
                              ({user.provider === 'naver' ? '네이버' : user.provider === 'kakao' ? '카카오' : user.provider})
                            </span>
                          )}
                        </span>
                        {user.role === "admin" && (
                          <span className="ml-2 px-2 py-0.5 bg-purple-100 text-purple-800 text-xs rounded-full">
                            관리자
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => {
                          setMobileMenuOpen(false);
                          setLocation("/profile");
                        }}
                        className="flex items-center py-2 text-lg font-medium text-neutral-800 hover:text-primary w-full text-left"
                      >
                        <User className="mr-2 h-5 w-5" />
                        내 프로필
                      </button>

                      {user.role === "admin" && (
                        <button
                          onClick={() => {
                            setMobileMenuOpen(false);
                            setLocation("/admin");
                          }}
                          className="flex items-center py-2 text-lg font-medium text-neutral-800 hover:text-primary w-full text-left"
                        >
                          <Settings className="mr-2 h-5 w-5" />
                          관리자 패널
                        </button>
                      )}

                      <button
                        onClick={() => {
                          handleLogout();
                          setMobileMenuOpen(false);
                        }}
                        className="flex items-center py-2 text-lg font-medium text-neutral-800 hover:text-primary"
                      >
                        <LogOut className="mr-2 h-5 w-5" />
                        로그아웃
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        setLocation("/auth");
                      }}
                      className="flex items-center py-2 text-lg font-medium text-neutral-800 hover:text-primary w-full text-left"
                    >
                      <LogIn className="mr-2 h-5 w-5" />
                      로그인 / 회원가입
                    </button>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
