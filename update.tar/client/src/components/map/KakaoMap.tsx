import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Property } from '@shared/schema';
import { Link } from 'wouter';

import { formatKoreanPrice } from '@/lib/formatter';

declare global {
  interface Window {
    kakao: any;
  }
}

function buildPriceInfoHtml(property: Property): string {
  let html = '';
  if (property.price) html += `<div style="color:#2563eb;font-weight:bold;">매매 ${formatKoreanPrice(property.price)}</div>`;
  if (property.deposit) html += `<div style="color:#2563eb;">전세 ${formatKoreanPrice(property.deposit)}</div>`;
  if (property.monthlyRent) html += `<div style="color:#2563eb;">월세 ${formatKoreanPrice(property.monthlyRent)}</div>`;
  return html || '<div style="color:#666;">가격 문의</div>';
}

interface KakaoMapProps {
  singleProperty?: Property;
  properties?: Property[];
  zoom?: number; // 기본 줌 레벨 (기본값: 3)
}

export default function KakaoMap({ singleProperty, properties: externalProperties, zoom = 3 }: KakaoMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markers = useRef<any[]>([]);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

  // 데이터 가져오기 (props가 없을 경우)
  const { data: fetchedProperties } = useQuery<Property[]>({
    queryKey: ['/api/properties'],
    enabled: !singleProperty && !externalProperties
  });

  const properties = singleProperty ? [singleProperty] : (externalProperties || fetchedProperties || []);

  // 1. SDK 초기화 (단순화된 로직)
  useEffect(() => {
    const initMap = () => {
      if (!mapContainer.current) return;
      if (mapInstance.current) return; // 이미 초기화됨

      if (!window.kakao.maps.services) {
        console.warn("카카오맵 서비스 라이브러리 대기 중...");
        setTimeout(initMap, 100);
        return;
      }

      const options = {
        center: new window.kakao.maps.LatLng(37.7466, 126.4881),
        level: zoom,
        draggable: true, // 태블릿 대응
        scrollwheel: true,
        disableDoubleClickZoom: false
      };

      const map = new window.kakao.maps.Map(mapContainer.current, options);
      mapInstance.current = map;

      // 태블릿 확/축소 강제 활성화
      map.setZoomable(true);
      map.setDraggable(true);

      setIsMapLoaded(true); // 마커 렌더링 시작 신호

      // 레이아웃 안정화 (깜빡임/깨짐 방지)
      setTimeout(() => {
        map.relayout();
        map.setCenter(options.center);
      }, 100);
    };

    // 로드 상태 체크 루프
    const checkKakao = () => {
      // kakao객체와 maps 객체가 로드되었는지 확인 (services는 load() 이후 확인)
      if (window.kakao && window.kakao.maps) {
        // autoload=false 환경 대응
        window.kakao.maps.load(() => {
          initMap();
        });
      } else {
        // 아직 로드 안됨 -> 100ms 후 재시도
        setTimeout(checkKakao, 100);
      }
    };

    // 타임아웃 설정 (5초 동안 로드 안되면 에러)
    const timeoutId = setTimeout(() => {
      if (!isMapLoaded) {
        console.error("카카오맵 로딩 시간 초과");
        // 에러 상태를 표시할 수 있는 로직 추가 가능
      }
    }, 5000);

    checkKakao();

    // 윈도우 리사이즈 대응
    const handleResize = () => {
      if (mapInstance.current) {
        mapInstance.current.relayout();
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', handleResize);
    };
  }, [zoom]);
  // 의존성 최소화: 줌 레벨이 바뀌지 않는 한 지도를 다시 만들지 않음.

  // 2. 마커 렌더링 (지도가 로드되고 데이터가 바뀌면 실행)
  useEffect(() => {
    if (!isMapLoaded || !mapInstance.current || properties.length === 0) return;

    const map = mapInstance.current;

    // 기존 마커 삭제
    markers.current.forEach(marker => marker.setMap(null));
    markers.current = [];

    const geocoder = new window.kakao.maps.services.Geocoder();
    const bounds = new window.kakao.maps.LatLngBounds();
    let validMarkersCount = 0;

    properties.forEach((prop, idx) => {
      // 마커 생성 헬퍼
      const addMarker = (coords: any) => {
        const marker = new window.kakao.maps.Marker({
          map: map,
          position: coords,
          title: prop.title,
          clickable: true
        });

        // 클릭 이벤트
        window.kakao.maps.event.addListener(marker, 'click', () => {
          setSelectedProperty(prop);
        });

        markers.current.push(marker);
        bounds.extend(coords);
        validMarkersCount++;

        // 바운드 혹은 센터 조정
        if (singleProperty) {
          map.setCenter(coords);
        } else if (validMarkersCount > 0) {
          // 여러 개일 때는 바운드 조정 (debounce 필요할 수 있으나 여기선 매번 호출해도 됨)
          map.setBounds(bounds);
        }
      };

      // 좌표 우선
      if (prop.latitude && prop.longitude) {
        addMarker(new window.kakao.maps.LatLng(prop.latitude, prop.longitude));
        return;
      }

      // 주소 검색 (좌표 없을 때)
      const district = prop.district || "";
      const detailAddress = prop.address || "";

      let searchAddr = "";
      if (district.includes("강화")) {
        searchAddr = `인천광역시 ${district} ${detailAddress}`;
      } else if (district.includes("서울")) {
        searchAddr = `${district} ${detailAddress}`;
      } else {
        searchAddr = `인천광역시 ${district} ${detailAddress}`;
      }

      const query = searchAddr.trim().replace(/\s+/g, ' ');

      if (query && query.length > 2) {
        geocoder.addressSearch(query, (result: any, status: any) => {
          if (status === window.kakao.maps.services.Status.OK) {
            const coords = new window.kakao.maps.LatLng(result[0].y, result[0].x);
            addMarker(coords);
          }
        });
      }
    });

  }, [isMapLoaded, properties, singleProperty]);

  // key를 사용하여 데이터를 갈아끼울 때 컴포넌트를 리셋? 
  // 아니오, 위 구조는 mapInstance를 유지하면서 마커만 다시 그리는 구조이므로 더 효율적입니다.
  // 다만, 부모에서 'key'를 바꿔서 강제 리마운트 시킬 수도 있습니다.

  return (
    <div
      className="relative w-full h-full bg-gray-100"
      data-no-swipe="true" // 스와이프 방지
      style={{ touchAction: 'none' }} // 태블릿 터치 전용
    >
      <div ref={mapContainer} className="w-full h-full" />

      {!isMapLoaded && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100/80 z-10 p-4 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary mb-2"></div>
          <span className="text-gray-500 text-sm font-medium">지도를 불러오는 중...</span>
          <span className="text-gray-400 text-xs mt-1">로딩이 늦어지면 새로고침을 해주세요.</span>
        </div>
      )}

      {/* 선택된 매물 오버레이 (커스텀 오버레이 대신 React UI 사용) */}
      {!singleProperty && selectedProperty && (
        <div className="absolute top-4 right-4 bg-white p-4 rounded-lg shadow-xl z-20 w-72 border border-gray-200"
          onClick={(e) => e.stopPropagation()} // 팝업 클릭 시 맵 이벤트 방지
        >
          <button
            className="absolute top-2 right-2 text-gray-400 hover:text-black"
            onClick={() => setSelectedProperty(null)}
          >
            ✕
          </button>
          <h4 className="font-bold text-lg mb-1 truncate text-gray-900">{selectedProperty.title}</h4>
          <div className="text-sm text-gray-500 mb-2">{selectedProperty.district} · {selectedProperty.type}</div>
          <div className="mb-3" dangerouslySetInnerHTML={{ __html: buildPriceInfoHtml(selectedProperty) }}></div>
          <Link href={`/properties/${selectedProperty.id}`} className="block text-center bg-blue-600 text-white font-medium py-2 rounded hover:bg-blue-700 transition">
            매물 보러가기
          </Link>
        </div>
      )}
    </div>
  );
}