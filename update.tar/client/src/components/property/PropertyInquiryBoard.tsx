import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { PropertyInquiry } from "@shared/schema";

// PropertyInquiry에 authorUsername 필드를 추가한 확장 타입
type PropertyInquiryWithAuthor = PropertyInquiry & {
  authorUsername?: string;
};

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { Loader2, MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ko } from "date-fns/locale";

interface PropertyInquiryBoardProps {
  propertyId: number;
}

// 문의 작성 폼 스키마
const inquiryFormSchema = z.object({
  title: z.string().min(2, "제목은 2자 이상이어야 합니다.").max(100, "제목은 100자 이하여야 합니다."),
  content: z.string().min(5, "내용은 5자 이상이어야 합니다.").max(1000, "내용은 1000자 이하여야 합니다."),
});

type InquiryFormValues = z.infer<typeof inquiryFormSchema>;

// 답변 작성 폼 스키마
const replyFormSchema = z.object({
  content: z.string().min(5, "내용은 5자 이상이어야 합니다.").max(500, "내용은 500자 이하여야 합니다."),
});

type ReplyFormValues = z.infer<typeof replyFormSchema>;

const PropertyInquiryBoard = ({ propertyId }: PropertyInquiryBoardProps) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("view");
  const [replyToId, setReplyToId] = useState<number | null>(null);
  const [selectedInquiryId, setSelectedInquiryId] = useState<number | null>(null);

  // 문의글 목록 조회
  const {
    data: inquiries,
    isLoading: inquiriesLoading,
    refetch: refetchInquiries
  } = useQuery<PropertyInquiryWithAuthor[]>({
    queryKey: [`/api/properties/${propertyId}/inquiries`],
    enabled: !!propertyId,
  });

  // 선택된 문의글 찾기
  const selectedInquiry = selectedInquiryId && inquiries
    ? inquiries.find(inquiry => inquiry.id === selectedInquiryId)
    : null;

  // 문의글 작성을 위한 폼
  const inquiryForm = useForm<InquiryFormValues>({
    resolver: zodResolver(inquiryFormSchema),
    defaultValues: {
      title: "",
      content: ""
    }
  });

  // 답변 작성을 위한 폼
  const replyForm = useForm<ReplyFormValues>({
    resolver: zodResolver(replyFormSchema),
    defaultValues: {
      content: ""
    }
  });

  // 문의글 작성 뮤테이션
  const inquiryMutation = useMutation({
    mutationFn: (values: InquiryFormValues) => {
      return apiRequest("POST", `/api/properties/${propertyId}/inquiries`, {
        ...values,
        propertyId,
        userId: user?.id,
        isReply: false,
        parentId: null
      });
    },
    onSuccess: () => {
      toast({
        title: "문의가 등록되었습니다",
        description: "부동산 담당자가 확인 후 답변드리겠습니다.",
      });
      inquiryForm.reset();
      setActiveTab("view");
      queryClient.invalidateQueries({ queryKey: [`/api/properties/${propertyId}/inquiries`] });
    },
    onError: (error) => {
      toast({
        title: "문의 등록 실패",
        description: "문의 등록 중 오류가 발생했습니다. 다시 시도해주세요.",
        variant: "destructive",
      });
      console.error("Inquiry submission error:", error);
    }
  });

  // 답변 작성 뮤테이션
  const replyMutation = useMutation({
    mutationFn: (values: ReplyFormValues) => {
      return apiRequest("POST", `/api/properties/${propertyId}/inquiries`, {
        title: "답변: " + (inquiries?.find(i => i.id === replyToId)?.title || "문의에 대한 답변"),
        content: values.content,
        propertyId,
        userId: user?.id,
        isReply: true,
        parentId: replyToId
      });
    },
    onSuccess: () => {
      toast({
        title: "답변이 등록되었습니다",
      });
      replyForm.reset();
      setReplyToId(null);
      queryClient.invalidateQueries({ queryKey: [`/api/properties/${propertyId}/inquiries`] });
    },
    onError: (error) => {
      toast({
        title: "답변 등록 실패",
        description: "답변 등록 중 오류가 발생했습니다. 다시 시도해주세요.",
        variant: "destructive",
      });
      console.error("Reply submission error:", error);
    }
  });

  // 문의글 삭제 뮤테이션
  const deleteMutation = useMutation({
    mutationFn: (inquiryId: number) => {
      return apiRequest("DELETE", `/api/properties/${propertyId}/inquiries/${inquiryId}`);
    },
    onSuccess: () => {
      toast({
        title: "삭제되었습니다",
      });
      if (selectedInquiryId) {
        setSelectedInquiryId(null);
      }
      queryClient.invalidateQueries({ queryKey: [`/api/properties/${propertyId}/inquiries`] });
    },
    onError: (error) => {
      toast({
        title: "삭제 실패",
        description: "삭제 중 오류가 발생했습니다. 다시 시도해주세요.",
        variant: "destructive",
      });
      console.error("Delete error:", error);
    }
  });

  // 문의글 제출 핸들러
  const onInquirySubmit = (data: InquiryFormValues) => {
    inquiryMutation.mutate(data);
  };

  // 답변 제출 핸들러
  const onReplySubmit = (data: ReplyFormValues) => {
    replyMutation.mutate(data);
  };

  // 답변 작성 모드로 전환하는 핸들러
  const handleReply = (inquiryId: number) => {
    setReplyToId(inquiryId);
    replyForm.reset();
  };

  // 문의글 선택 핸들러
  const handleInquirySelect = (inquiryId: number) => {
    if (selectedInquiryId === inquiryId) {
      setSelectedInquiryId(null);
    } else {
      setSelectedInquiryId(inquiryId);
    }
  };

  // 문의글 삭제 핸들러
  const handleDelete = (inquiryId: number) => {
    if (window.confirm("정말로 이 글을 삭제하시겠습니까?")) {
      deleteMutation.mutate(inquiryId);
    }
  };

  // 사용자 권한 체크 (본인이 작성한 글이거나 관리자인 경우)
  const canManageInquiry = (inquiry: PropertyInquiry) => {
    return user?.id === inquiry.userId || user?.role === "admin";
  };

  // 로그인하지 않은 사용자에게는 제한된 뷰를 제공, 문의 작성 제한
  const isLoggedIn = !!user;

  return (
    <div>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="view">문의 목록</TabsTrigger>
          {isLoggedIn ? (
            <TabsTrigger value="write">문의 작성</TabsTrigger>
          ) : (
            <TabsTrigger value="login" onClick={() => window.location.href = "/auth"}>
              로그인 필요
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="view" className="py-4">
          {inquiriesLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : inquiries && inquiries.length > 0 ? (
            <div className="space-y-4">
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-muted/40">
                    <tr>
                      <th className="text-left p-3 font-medium">제목</th>
                      <th className="text-left p-3 font-medium w-24">작성자</th>
                      <th className="text-left p-3 font-medium w-28">작성일</th>
                      <th className="text-left p-3 font-medium w-20">관리</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inquiries.map(inquiry => (
                      <tr
                        key={inquiry.id}
                        className={`border-t hover:bg-muted/20 cursor-pointer ${selectedInquiryId === inquiry.id ? 'bg-muted/30' : ''} ${inquiry.isReply ? 'bg-muted/10' : ''}`}
                        onClick={() => handleInquirySelect(inquiry.id)}
                      >
                        <td className="p-3">
                          <div className="flex items-center">
                            {inquiry.isReply && <span className="text-primary mr-2 text-sm">[답변]</span>}
                            {inquiry.title}
                          </div>
                        </td>
                        <td className="p-3 text-sm">{inquiry.authorUsername || "알 수 없음"}</td>
                        <td className="p-3 text-sm">
                          {inquiry.createdAt ? formatDistanceToNow(new Date(inquiry.createdAt), { addSuffix: true, locale: ko }) : ""}
                        </td>
                        <td className="p-3">
                          <div className="flex space-x-1">
                            {!inquiry.isReply && user?.role === "admin" && (
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleReply(inquiry.id);
                                }}
                              >
                                <MessageCircle size={14} />
                              </Button>
                            )}
                            {canManageInquiry(inquiry) && (
                              <Button
                                variant="destructive"
                                size="icon"
                                className="h-8 w-8"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(inquiry.id);
                                }}
                              >
                                <span className="text-xs">✕</span>
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {selectedInquiryId && selectedInquiry && (
                <div className="mt-4 border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-lg">{selectedInquiry.title}</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedInquiryId(null)}
                    >
                      닫기
                    </Button>
                  </div>
                  <p className="mb-4 whitespace-pre-wrap">{selectedInquiry.content}</p>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>작성자: {selectedInquiry.authorUsername || "알 수 없음"}</span>
                    <span>{selectedInquiry.createdAt ? formatDistanceToNow(new Date(selectedInquiry.createdAt), { addSuffix: true, locale: ko }) : ""}</span>
                  </div>
                </div>
              )}

              {replyToId && user?.role === "admin" && (
                <Card className="mt-6">
                  <CardContent className="pt-6">
                    <h3 className="text-lg font-bold mb-4">답변 작성</h3>
                    <Form {...replyForm}>
                      <form onSubmit={replyForm.handleSubmit(onReplySubmit)} className="space-y-4">
                        <FormField
                          control={replyForm.control}
                          name="content"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>답변 내용</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="답변 내용을 작성해주세요"
                                  rows={5}
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-end gap-2">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setReplyToId(null)}
                          >
                            취소
                          </Button>
                          <Button
                            type="submit"
                            disabled={replyMutation.isPending}
                          >
                            {replyMutation.isPending ? "제출 중..." : "답변 등록"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-gray-500">아직 문의글이 없습니다.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="write" className="py-4">
          <Form {...inquiryForm}>
            <form onSubmit={inquiryForm.handleSubmit(onInquirySubmit)} className="space-y-4">
              <FormField
                control={inquiryForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>제목</FormLabel>
                    <FormControl>
                      <Input placeholder="문의 제목을 입력하세요" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={inquiryForm.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>내용</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="문의 내용을 상세히 작성해주세요"
                        rows={6}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full btn-primary-cta h-12"
                disabled={inquiryMutation.isPending}
              >
                {inquiryMutation.isPending ? "제출 중..." : "문의 등록하기"}
              </Button>
            </form>
          </Form>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PropertyInquiryBoard;