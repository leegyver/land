
import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Property } from '@shared/schema';
import { Link } from 'wouter';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useSaju } from '@/contexts/SajuContext';
import { getCompatibilityScore } from '@/lib/saju';
import SajuFormModal from '@/components/saju/SajuFormModal';
import SajuDetailModal from '@/components/saju/SajuDetailModal';
import TarotModal from '@/components/tarot/TarotModal';
import { Sparkles, HelpCircle } from 'lucide-react';
import { formatKoreanPrice } from '@/lib/formatter';

declare global {
  interface Window {
    kakao: any;
    kakaoKey?: string;
    kakaoMapLoaded?: boolean;
  }
}


interface PropertyMapProps {
  properties?: Property[];
}

const PropertyMap = ({ properties: passedProperties }: PropertyMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any>(null);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [infoWindow, setInfoWindow] = useState<any>(null);

  // Saju & Tarot Logic
  const { sajuData, openSajuModal } = useSaju();
  const [isTarotOpen, setIsTarotOpen] = useState(false);
  const [isSajuDetailOpen, setIsSajuDetailOpen] = useState(false);
  const [compatibility, setCompatibility] = useState<{
    score: number,
    comment: string,
    details?: {
      investment: { style: string, advice: string },
      styling: { colors: string, tip: string },
      location: string
    }
  } | null>(null);

  // 모든 매물 데이터 가져오기 (props가 없을 때만)
  const { data: fetchedProperties, isLoading } = useQuery<Property[]>({
    queryKey: ['/api/properties'],
    enabled: !passedProperties,
  });

  const properties = passedProperties || fetchedProperties;

  // Calculate compatibility when selected property changes
  useEffect(() => {
    if (selectedProperty && sajuData) {
      // Mocking features for now as they might not be in standard schema explicitly for all items
      // In real app, we would parse `property.direction` and `property.floor`
      const features = {
        id: selectedProperty.id,
        direction: selectedProperty.direction || '남향', // Default fallbacks
        floor: selectedProperty.floor || 5
      };
      const result = getCompatibilityScore(sajuData, features);
      setCompatibility(result);
    } else {
      setCompatibility(null);
    }
  }, [selectedProperty, sajuData]);


  // 카카오맵 초기화
  useEffect(() => {
    // HTML에 이미 삽입된 카카오맵 SDK 스크립트를 확인
    const waitForKakaoSDK = () => {
      // kakao.maps.Map 객체가 준비되었는지 직접 확인 (autoload=true 상황)
      if (window.kakao && window.kakao.maps && window.kakao.maps.Map) {
        console.log("카카오맵 SDK 준비됨, 초기화 시작");
        initializeMap();
        return;
      }

      console.log("카카오맵 SDK 로딩 대기 중...");
      // 일정 시간 후 다시 확인
      setTimeout(waitForKakaoSDK, 100);
    };

    waitForKakaoSDK();
  }, []);

  // 맵 초기화 함수
  const initializeMap = () => {
    if (!mapRef.current) return;
    if (map) return; // 이미 지도가 생성됨

    if (!window.kakao.maps.services || !window.kakao.maps.services.Geocoder) {
      console.warn("카카오맵 서비스 라이브러리 대기 중...");
      setTimeout(initializeMap, 100);
      return;
    }

    try {
      console.log("카카오맵 인스턴스 생성 시도");

      // 기본 위치를 강화군 중심으로 설정
      const options = {
        center: new window.kakao.maps.LatLng(37.7464, 126.4878), // 강화군 중심 좌표
        level: 9 // 확대 레벨 (숫자가 작을수록 확대)
      };

      const kakaoMap = new window.kakao.maps.Map(mapRef.current, options);
      setMap(kakaoMap);
      console.log("카카오맵 생성 성공");

      // 정보 윈도우 생성
      const kakaoInfoWindow = new window.kakao.maps.InfoWindow({ zIndex: 1 });
      setInfoWindow(kakaoInfoWindow);

      // 레이아웃 안정화 (초기 로딩 시 지도가 깨지거나 안 보이는 문제 해결)
      setTimeout(() => {
        kakaoMap.relayout();
        kakaoMap.setCenter(options.center);
        console.log("카카오맵 레이아웃 재계산 완료");
      }, 100);
    } catch (error) {
      console.error("카카오맵 초기화 오류:", error);
    }
  };

  // 매물 마커 표시
  useEffect(() => {
    if (!map || !properties || properties.length === 0) {
      return;
    }

    try {
      const geocoder = new window.kakao.maps.services.Geocoder();
      const bounds = new window.kakao.maps.LatLngBounds();
      const markers: any[] = [];

      // 매물들의 좌표를 얻기 위한 함수
      const getCoordinates = (property: Property, index: number) => {
        try {
          const district = property.district || "";
          const detailAddress = property.address || "";

          let searchAddr = "";
          if (district.includes("강화")) {
            searchAddr = `인천광역시 ${district} ${detailAddress}`;
          } else if (district.includes("서울")) {
            searchAddr = `${district} ${detailAddress}`;
          } else {
            searchAddr = `인천광역시 ${district} ${detailAddress}`;
          }

          const address = searchAddr.trim().replace(/\s+/g, ' ');

          if (address && address.length > 2) {
            geocoder.addressSearch(address, (result: any, status: any) => {
              if (status === window.kakao.maps.services.Status.OK) {
                const position = new window.kakao.maps.LatLng(result[0].y, result[0].x);
                createMarker(property, position, index);
                bounds.extend(position);
                console.log(`매물 마커 생성 완료: ${property.title} (${address})`);
              } else {
                console.warn(`지오코딩 실패: ${property.title} (주소: ${address}, 상태: ${status})`);
                // 랜덤 위치 폴백 제거 (주소 오표기 오해 방지)
              }

              // 모든 매물 처리가 끝났을 때 지도 범위 조정
              if (index === properties.length - 1) {
                setTimeout(() => {
                  if (!bounds.isEmpty()) {
                    map.setBounds(bounds);
                    map.relayout();
                  }
                }, 100);
              }
            });
          }
        } catch (error) {
          console.error("주소 검색 오류:", error);
        }
      };

      // 마커 생성 함수
      const createMarker = (property: Property, position: any, index: number) => {
        // 마커 생성
        const marker = new window.kakao.maps.Marker({
          map: map,
          position: position,
          title: property.title,
        });

        markers.push(marker);

        // 마커 클릭 이벤트
        window.kakao.maps.event.addListener(marker, 'click', () => {
          // 클릭된 매물 정보 설정
          setSelectedProperty(property);

          let dealTypeText = '';
          if (property.dealType && Array.isArray(property.dealType)) {
            const filteredTypes = property.dealType.filter(t => ['매매', '전세', '월세'].includes(t));
            dealTypeText = filteredTypes.length > 0 ? filteredTypes.join(', ') : '';
          }

          const content = `
          <div style="padding: 8px; max-width: 325px; font-family: 'Apple SD Gothic Neo', 'Noto Sans KR', sans-serif;">
            <div style="font-weight: bold; margin-bottom: 4px; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${property.title}</div>
            <div style="color: #666; font-size: 12px; margin-bottom: 4px;">${property.type}${dealTypeText ? ' · ' + dealTypeText : ''}</div>
            <div style="color: #2563eb; font-weight: bold; font-size: 13px;">${formatKoreanPrice(property.price || 0)}</div>
          </div>
        `;

          infoWindow.setContent(content);
          infoWindow.open(map, marker);
        });
      };

      properties.forEach((property, index) => {
        getCoordinates(property, index);
      });

      return () => {
        markers.forEach(marker => marker.setMap(null));
      };

    } catch (error) {
      console.error("매물 마커 생성 중 오류 발생:", error);
      return () => { };
    }
  }, [map, properties, infoWindow]); // removed sajuData dependency to avoid re-rendering markers unnecessarily

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh] bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full">
      <div ref={mapRef} className="w-full h-full"></div>

      {/* 선택된 매물 정보 패널 */}
      {selectedProperty && (
        <div className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-80 bg-white rounded-lg shadow-lg p-4 z-10 animate-in slide-in-from-bottom-5">
          <button
            className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
            onClick={() => setSelectedProperty(null)}
          >
            ✕
          </button>

          <Link href={`/properties/${selectedProperty.id}`}>
            <h3 className="font-bold text-lg mb-2 hover:text-primary transition-colors cursor-pointer">
              {selectedProperty.title}
            </h3>
          </Link>

          <div className="flex flex-wrap gap-2 mb-2">
            <Badge variant="outline" className="bg-primary/10 text-primary">
              {selectedProperty.type}
            </Badge>
            {selectedProperty.dealType && Array.isArray(selectedProperty.dealType) && selectedProperty.dealType
              .filter(t => ['매매', '전세', '월세'].includes(t))
              .map((type, idx) => (
                <Badge
                  key={idx}
                  variant="outline"
                  className={`${type === '매매' ? 'bg-red-100 text-red-800' :
                    type === '전세' ? 'bg-amber-100 text-amber-800' :
                      type === '월세' ? 'bg-indigo-100 text-indigo-800' :
                        'bg-gray-100 text-gray-800'
                    }`}
                >
                  {type}
                </Badge>
              ))}
          </div>

          {/* Saju Compatibility Section */}
          <div className="mb-3 p-3 bg-slate-50 rounded-md border border-slate-200">
            {sajuData && compatibility ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-700 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-purple-600" /> 사주 궁합 점수
                  </span>
                  <span className={`text-sm font-bold ${compatibility.score >= 80 ? 'text-green-600' : compatibility.score >= 50 ? 'text-amber-600' : 'text-red-500'}`}>
                    {compatibility.score}점
                  </span>
                </div>

                <div className="p-2 bg-purple-100/30 rounded text-xs text-slate-600 leading-snug">
                  {compatibility.comment}
                </div>

                {compatibility.details && (
                  <div className="space-y-2 pt-1">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-1 rounded">운세</span>
                        <span className="text-[10px] font-bold text-slate-700">{compatibility.details.investment.style}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{compatibility.details.investment.advice}</p>
                    </div>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] font-bold text-green-600 bg-green-50 px-1 rounded">추천</span>
                        <span className="text-[10px] font-bold text-slate-700">색상: {compatibility.details.styling.colors}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{compatibility.details.styling.tip}</p>
                    </div>
                  </div>
                )}

                <div className="pt-2 border-t border-slate-200 flex justify-between items-center bg-slate-100/30 -mx-3 -mb-3 p-2 px-3 rounded-b-md">
                  <button
                    className="text-[10px] text-purple-600 font-bold hover:underline"
                    onClick={() => setIsSajuDetailOpen(true)}
                  >
                    상세 분석 더보기 &gt;
                  </button>
                  <button
                    className="text-[10px] text-purple-600 font-bold flex items-center gap-0.5 hover:underline"
                    onClick={() => setIsTarotOpen(true)}
                  >
                    <HelpCircle className="w-2.5 h-2.5" /> 타로 조언
                  </button>
                </div>
              </div>
            ) : (
              <div
                onClick={openSajuModal}
                className="flex items-center justify-between cursor-pointer hover:bg-slate-100 transition-colors p-1 rounded"
              >
                <span className="text-sm text-slate-600 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-slate-400" /> 내 사주와 맞을까?
                </span>
                <Button variant="ghost" size="sm" className="h-6 text-xs text-purple-600">
                  알아보기 &gt;
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-x-2 gap-y-1 mb-3 text-sm">
            <div className="text-gray-500">지역:</div>
            <div>{selectedProperty.district}</div>

            <div className="text-gray-500">면적:</div>
            <div>
              {selectedProperty.size} m²
              {Number(selectedProperty.size) > 0 && ` (${(Number(selectedProperty.size) * 0.3025).toFixed(1)} 평)`}
            </div>

            <div className="text-gray-500">가격:</div>
            <div className="font-semibold text-primary">
              {formatKoreanPrice(selectedProperty.price || 0)}
            </div>
          </div>

          <div className="flex gap-2">
            <Link
              href={`/properties/${selectedProperty.id}`}
              className="flex-1 bg-primary hover:bg-secondary text-white text-center py-2 rounded transition-colors text-sm flex items-center justify-center"
            >
              상세보기
            </Link>
            <Button
              onClick={() => setIsTarotOpen(true)}
              variant="outline"
              className="flex-1 border-purple-200 hover:bg-purple-50 hover:text-purple-700 text-purple-600 text-sm"
            >
              <HelpCircle className="w-3 h-3 mr-1" /> 타로 조언
            </Button>
          </div>
        </div>
      )
      }

      {/* Modals */}
      <SajuFormModal />
      {
        selectedProperty && (
          <TarotModal
            isOpen={isTarotOpen}
            onClose={() => setIsTarotOpen(false)}
            propertyTitle={selectedProperty.title}
          />
        )
      }
      <SajuDetailModal
        isOpen={isSajuDetailOpen}
        onClose={() => setIsSajuDetailOpen(false)}
        sajuData={sajuData}
      />
    </div >
  );
};

export default PropertyMap;