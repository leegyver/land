
import { useEffect, useRef, useState } from 'react';
import { Property } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';

interface KakaoMapProps {
  zoom?: number;
  properties?: Property[];
  singleProperty?: Property;
}

const KakaoMap = ({ zoom = 8, properties: externalProperties, singleProperty }: KakaoMapProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markers = useRef<any[]>([]);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [isMapLoaded, setIsMapLoaded] = useState(false);

  // 데이터 가져오기 (props가 없을 경우 대비)
  const { data: fetchedProperties } = useQuery<Property[]>({
    queryKey: ['/api/properties'],
    enabled: !singleProperty && !externalProperties
  });

  const properties = singleProperty ? [singleProperty] : (externalProperties || fetchedProperties || []);

  // 1. 지도 초기화 및 마커 렌더링 (통합 제어)
  useEffect(() => {
    if (!mapContainer.current) return;

    let isMounted = true;

    const checkAndInit = () => {
      const initMap = () => {
        if (!isMounted || !mapContainer.current) return;

        // 1. 지도 인스턴스 생성 (한 번만)
        if (!mapInstance.current) {
          console.log("KakaoMap: 지도 신규 인스턴스 생성");
          const options = {
            center: new window.kakao.maps.LatLng(37.7466, 126.4881),
            level: zoom,
            draggable: true,
            scrollwheel: true
          };
          try {
            const map = new window.kakao.maps.Map(mapContainer.current, options);
            mapInstance.current = map;
            setIsMapLoaded(true);

            setTimeout(() => {
              if (map && isMounted) {
                map.relayout();
                map.setCenter(options.center);
              }
            }, 100);
          } catch (err) {
            console.error("KakaoMap: 지도 생성 실패", err);
            return;
          }
        }

        // 2. 마커 렌더링 로직
        const map = mapInstance.current;
        if (!map || !properties || properties.length === 0) {
          // 데이터가 없을 때 기존 마커만 제거
          markers.current.forEach(m => m.setMap(null));
          markers.current = [];
          return;
        }

        console.log(`KakaoMap: ${properties.length}개 마커 렌더링 시작`);

        // 기존 마커 즉시 제거하여 중복 방지
        markers.current.forEach(m => m.setMap(null));
        markers.current = [];

        const geocoder = new window.kakao.maps.services.Geocoder();
        const bounds = new window.kakao.maps.LatLngBounds();

        properties.forEach((prop) => {
          const addMarker = (coords: any) => {
            if (!isMounted || !map) return;
            const marker = new window.kakao.maps.Marker({
              map: map,
              position: coords,
              title: prop.title,
              clickable: true
            });

            window.kakao.maps.event.addListener(marker, 'click', () => {
              if (isMounted) setSelectedProperty(prop);
            });

            markers.current.push(marker);
            bounds.extend(coords);

            // 위치 조정
            if (singleProperty) {
              map.setCenter(coords);
            } else if (!bounds.isEmpty()) {
              map.setBounds(bounds);
            }
          };

          if (prop.latitude && prop.longitude) {
            addMarker(new window.kakao.maps.LatLng(prop.latitude, prop.longitude));
          } else {
            const district = prop.district || "";
            const detailAddress = prop.address || "";
            const query = `${district.includes("강화") || district.includes("서울") ? district : "인천광역시 " + district} ${detailAddress}`.trim().replace(/\s+/g, ' ');

            if (query.length > 2) {
              geocoder.addressSearch(query, (result: any, status: any) => {
                if (status === window.kakao.maps.services.Status.OK && isMounted) {
                  addMarker(new window.kakao.maps.LatLng(result[0].y, result[0].x));
                }
              });
            }
          }
        });
      };

      // SDK 로드 확인 및 load 호출 (autoload=false 대응)
      if (window.kakao && window.kakao.maps && window.kakao.maps.load) {
        window.kakao.maps.load(initMap);
      } else {
        setTimeout(checkAndInit, 200);
      }
    };

    checkAndInit();

    return () => {
      isMounted = false;
    };
  }, [zoom, properties, singleProperty]); // 의존성 유지

  return (
    <div
      className="relative w-full h-full bg-gray-100"
      data-no-swipe="true"
      style={{ touchAction: 'none' }}
    >
      <div ref={mapContainer} className="w-full h-full" />

      {!isMapLoaded && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100/80 z-10 p-4 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary mb-2"></div>
          <span className="text-gray-500 text-sm font-medium">지도를 불러오는 중...</span>
          <span className="text-gray-400 text-xs mt-1">로딩이 늦어지면 새로고침을 해주세요.</span>
        </div>
      )}

      {!singleProperty && selectedProperty && (
        <div className="absolute top-4 right-4 bg-white p-4 rounded-lg shadow-xl z-20 w-72 border border-gray-200"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            className="absolute top-2 right-2 text-gray-400 hover:text-black"
            onClick={() => setSelectedProperty(null)}
          >
            ✕
          </button>
          <h4 className="font-bold text-lg mb-1 truncate text-gray-900">{selectedProperty.title}</h4>
          <p className="text-gray-500 text-xs mb-3 truncate">{selectedProperty.address}</p>
          <div className="flex justify-between items-center bg-gray-50 p-2 rounded">
            <span className="text-primary font-bold text-base">
              {selectedProperty.price}
            </span>
            <a
              href={`/properties/${selectedProperty.id}`}
              className="text-xs text-blue-600 hover:underline font-bold"
            >
              상세보기 &gt;
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default KakaoMap;