
import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Property } from '@shared/schema';
import { Link } from 'wouter';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useSaju } from '@/contexts/SajuContext';
import { getCompatibilityScore } from '@/lib/saju';
import SajuFormModal from '@/components/saju/SajuFormModal';
import SajuDetailModal from '@/components/saju/SajuDetailModal';
import TarotModal from '@/components/tarot/TarotModal';
import { Sparkles, HelpCircle } from 'lucide-react';
import { formatKoreanPrice } from '@/lib/formatter';

declare global {
  interface Window {
    kakao: any;
    kakaoKey?: string;
    kakaoMapLoaded?: boolean;
  }
}

interface PropertyMapProps {
  properties?: Property[];
}

const PropertyMap = ({ properties: passedProperties }: PropertyMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null); // 명시적인 인스턴스 추적용
  const [map, setMap] = useState<any>(null);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [infoWindow, setInfoWindow] = useState<any>(null);

  // Saju & Tarot Logic
  const { sajuData, openSajuModal } = useSaju();
  const [isTarotOpen, setIsTarotOpen] = useState(false);
  const [isSajuDetailOpen, setIsSajuDetailOpen] = useState(false);
  const [compatibility, setCompatibility] = useState<{
    score: number,
    comment: string,
    details?: {
      investment: { style: string, advice: string },
      styling: { colors: string, tip: string },
      location: string
    }
  } | null>(null);

  // 모든 매물 데이터 가져오기 (props가 없을 때만)
  const { data: fetchedProperties, isLoading } = useQuery<Property[]>({
    queryKey: ['/api/properties'],
    enabled: !passedProperties,
  });

  const properties = passedProperties || fetchedProperties;

  // 로딩 상태 결정: 외부 속성이 없을 때만 내부 로딩 상태를 따름
  const isMapDataLoading = !passedProperties && isLoading;

  // Calculate compatibility when selected property changes
  useEffect(() => {
    if (selectedProperty && sajuData) {
      const features = {
        id: selectedProperty.id,
        direction: selectedProperty.direction || '남향',
        floor: selectedProperty.floor || 5
      };
      const result = getCompatibilityScore(sajuData, features);
      setCompatibility(result);
    } else {
      setCompatibility(null);
    }
  }, [selectedProperty, sajuData]);


  const [isInitialized, setIsInitialized] = useState(false);

  // 1. 카카오맵 인스턴스 초기화
  useEffect(() => {
    // 이미 초기화되었거나 컨테이너가 없으면 실행 중단 (isMapDataLoading이 의존성에 추가됨)
    if (isInitialized || !mapRef.current || isMapDataLoading) {
      console.log("PropertyMap: 초기화 대기 중...", { isInitialized, hasRef: !!mapRef.current, isMapDataLoading });
      return;
    }

    const initMap = () => {
      // 이미 인스턴스가 생성되었는지 다시 확인
      if (mapInstanceRef.current || !mapRef.current) return;

      console.log("PropertyMap: 지도 인스턴스 생성 시도");
      try {
        const options = {
          center: new window.kakao.maps.LatLng(37.7464, 126.4878),
          level: 9
        };

        const kakaoMap = new window.kakao.maps.Map(mapRef.current, options);
        mapInstanceRef.current = kakaoMap; //Ref에도 저장
        setMap(kakaoMap);
        setInfoWindow(new window.kakao.maps.InfoWindow({ zIndex: 1 }));
        setIsInitialized(true);

        setTimeout(() => {
          if (kakaoMap) {
            kakaoMap.relayout();
            kakaoMap.setCenter(options.center);
          }
        }, 100);
      } catch (err) {
        console.error("PropertyMap: 지도 객체 생성 에러", err);
        setTimeout(initMap, 500);
      }
    };

    const loadKakao = () => {
      if (window.kakao && window.kakao.maps && window.kakao.maps.load) {
        window.kakao.maps.load(initMap);
      } else {
        setTimeout(loadKakao, 100);
      }
    };

    loadKakao();
  }, [isInitialized, isMapDataLoading]); // isMapDataLoading이 false가 되는 순간(DIV 등장 시점) 실행됨

  // 2. 매물 마커 렌더링 (지도가 준비된 후 데이터가 있을 때만 실행)
  useEffect(() => {
    if (!isInitialized || !map || !properties || properties.length === 0) {
      return;
    }

    const geocoder = new window.kakao.maps.services.Geocoder();
    const bounds = new window.kakao.maps.LatLngBounds();
    const markers: any[] = [];
    let isMounted = true;

    console.log(`PropertyMap: ${properties.length}개 마커 렌더링 호출`);

    properties.forEach((property) => {
      const district = property.district || "";
      const detailAddress = property.address || "";
      const searchAddr = district.includes("강화") || district.includes("서울")
        ? `${district} ${detailAddress}`
        : `인천광역시 ${district} ${detailAddress}`;

      const query = searchAddr.trim().replace(/\s+/g, ' ');

      if (query.length > 2) {
        geocoder.addressSearch(query, (result: any, status: any) => {
          if (!isMounted || !map) return;

          if (status === window.kakao.maps.services.Status.OK) {
            const position = new window.kakao.maps.LatLng(result[0].y, result[0].x);

            const marker = new window.kakao.maps.Marker({
              map: map,
              position: position,
              title: property.title,
            });

            markers.push(marker);
            bounds.extend(position);

            window.kakao.maps.event.addListener(marker, 'click', () => {
              setSelectedProperty(property);
              const dealTypeText = (property.dealType || []).filter(t => ['매매', '전세', '월세'].includes(t)).join(', ');
              const content = `
                <div style="padding: 8px; max-width: 325px; font-family: sans-serif;">
                  <div style="font-weight: bold; font-size: 14px;">${property.title}</div>
                  <div style="color: #666; font-size: 12px;">${property.type}${dealTypeText ? ' · ' + dealTypeText : ''}</div>
                  <div style="color: #2563eb; font-weight: bold; font-size: 13px;">${formatKoreanPrice(property.price || 0)}</div>
                </div>
              `;
              infoWindow?.setContent(content);
              infoWindow?.open(map, marker);
            });

            if (!bounds.isEmpty()) {
              map.setBounds(bounds);
            }
          }
        });
      }
    });

    return () => {
      isMounted = false;
      markers.forEach(m => m.setMap(null));
      console.log("PropertyMap: 마커 클린업");
    };
  }, [isInitialized, properties, map, infoWindow]);


  if (isMapDataLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh] bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full">
      <div ref={mapRef} className="w-full h-full"></div>

      {/* 선택된 매물 정보 패널 */}
      {selectedProperty && (
        <div className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-80 bg-white rounded-lg shadow-lg p-4 z-10 animate-in slide-in-from-bottom-5">
          <button
            className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
            onClick={() => setSelectedProperty(null)}
          >
            ✕
          </button>

          <Link href={`/properties/${selectedProperty.id}`}>
            <h3 className="font-bold text-lg mb-2 hover:text-primary transition-colors cursor-pointer">
              {selectedProperty.title}
            </h3>
          </Link>

          <div className="flex flex-wrap gap-2 mb-2">
            <Badge variant="outline" className="bg-primary/10 text-primary">
              {selectedProperty.type}
            </Badge>
            {selectedProperty.dealType && Array.isArray(selectedProperty.dealType) && selectedProperty.dealType
              .filter(t => ['매매', '전세', '월세'].includes(t))
              .map((type, idx) => (
                <Badge
                  key={idx}
                  variant="outline"
                  className={`${type === '매매' ? 'bg-red-100 text-red-800' :
                    type === '전세' ? 'bg-amber-100 text-amber-800' :
                      type === '월세' ? 'bg-indigo-100 text-indigo-800' :
                        'bg-gray-100 text-gray-800'
                    }`}
                >
                  {type}
                </Badge>
              ))}
          </div>

          {/* Saju Compatibility Section */}
          <div className="mb-3 p-3 bg-slate-50 rounded-md border border-slate-200">
            {sajuData && compatibility ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-700 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-purple-600" /> 사주 궁합 점수
                  </span>
                  <span className={`text-sm font-bold ${compatibility.score >= 80 ? 'text-green-600' : compatibility.score >= 50 ? 'text-amber-600' : 'text-red-500'}`}>
                    {compatibility.score}점
                  </span>
                </div>

                <div className="p-2 bg-purple-100/30 rounded text-xs text-slate-600 leading-snug">
                  {compatibility.comment}
                </div>

                {compatibility.details && (
                  <div className="space-y-2 pt-1">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-1 rounded">운세</span>
                        <span className="text-[10px] font-bold text-slate-700">{compatibility.details.investment.style}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{compatibility.details.investment.advice}</p>
                    </div>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] font-bold text-green-600 bg-green-50 px-1 rounded">추천</span>
                        <span className="text-[10px] font-bold text-slate-700">색상: {compatibility.details.styling.colors}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{compatibility.details.styling.tip}</p>
                    </div>
                  </div>
                )}

                <div className="pt-2 border-t border-slate-200 flex justify-between items-center bg-slate-100/30 -mx-3 -mb-3 p-2 px-3 rounded-b-md">
                  <button
                    className="text-[10px] text-purple-600 font-bold hover:underline"
                    onClick={() => setIsSajuDetailOpen(true)}
                  >
                    상세 분석 더보기 &gt;
                  </button>
                  <button
                    className="text-[10px] text-purple-600 font-bold flex items-center gap-0.5 hover:underline"
                    onClick={() => setIsTarotOpen(true)}
                  >
                    <HelpCircle className="w-2.5 h-2.5" /> 타로 조언
                  </button>
                </div>
              </div>
            ) : (
              <div
                onClick={openSajuModal}
                className="flex items-center justify-between cursor-pointer hover:bg-slate-100 transition-colors p-1 rounded"
              >
                <span className="text-sm text-slate-600 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-slate-400" /> 내 사주와 맞을까?
                </span>
                <Button variant="ghost" size="sm" className="h-6 text-xs text-purple-600">
                  알아보기 &gt;
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-x-2 gap-y-1 mb-3 text-sm">
            <div className="text-gray-500">지역:</div>
            <div>{selectedProperty.district}</div>

            <div className="text-gray-500">면적:</div>
            <div>
              {selectedProperty.size} m²
              {Number(selectedProperty.size) > 0 && ` (${(Number(selectedProperty.size) * 0.3025).toFixed(1)} 평)`}
            </div>

            <div className="text-gray-500">가격:</div>
            <div className="font-semibold text-primary">
              {formatKoreanPrice(selectedProperty.price || 0)}
            </div>
          </div>

          <div className="flex gap-2">
            <Link
              href={`/properties/${selectedProperty.id}`}
              className="flex-1 bg-primary hover:bg-secondary text-white text-center py-2 rounded transition-colors text-sm flex items-center justify-center"
            >
              상세보기
            </Link>
            <Button
              onClick={() => setIsTarotOpen(true)}
              variant="outline"
              className="flex-1 border-purple-200 hover:bg-purple-50 hover:text-purple-700 text-purple-600 text-sm"
            >
              <HelpCircle className="w-3 h-3 mr-1" /> 타로 조언
            </Button>
          </div>
        </div>
      )
      }

      {/* Modals */}
      <SajuFormModal />
      {
        selectedProperty && (
          <TarotModal
            isOpen={isTarotOpen}
            onClose={() => setIsTarotOpen(false)}
            propertyTitle={selectedProperty.title}
          />
        )
      }
      <SajuDetailModal
        isOpen={isSajuDetailOpen}
        onClose={() => setIsSajuDetailOpen(false)}
        sajuData={sajuData}
      />
    </div >
  );
};

export default PropertyMap;